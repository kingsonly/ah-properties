<?php
return [
    'adminEmail' => 'admin@example.com',
	'bsVersion' => '4.5.0',
	'bsDependencyEnabled' => false,
];


<?php

namespace frontend\models;

use Yii;


/**
 * This is the model class for table "config".
 *
 * @property int $id
 * @property string $settings_key
 * @property string $settings_value
 * @property int $status
 */
class Config extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'config';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['settings_key', 'settings_value', 'status'], 'required'],
            [['status'], 'integer'],
            [['settings_key', 'settings_value'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'settings_key' => 'Settings Key',
            'settings_value' => 'Settings Value',
            'status' => 'Status',
        ];
    }
	
	
	
	
	public static function sendSms($sendto,$message){
		$owneremail="kingsonly13c@gmail.com";
		$subacct="BUYMB";
		$subacctpwd="firstoctober";
		$sender = 'KDM';
		
		$url =
		"http://www.smslive247.com/http/index.aspx?" . "cmd=sendquickmsg"
		. "&owneremail=" . UrlEncode($owneremail)
		. "&subacct=" . UrlEncode($subacct)
		. "&subacctpwd=" . UrlEncode($subacctpwd) . "&message=" . UrlEncode($message)."&sendto=".UrlEncode($sendto)."&sender=".UrlEncode($sender);
		/* call the URL */


		if ($f = @fopen($url, "r")){ 
			$answer = fgets($f, 255);
			if (substr($answer, 0, 1) == "+"){
				
				return "SMS to $dnr was successful.";
				
			} elseif($answer){
				return $answer;
			} else {
				return 0;
			}
		} else {
			return 0;
		}

	}
	
	

	
}
